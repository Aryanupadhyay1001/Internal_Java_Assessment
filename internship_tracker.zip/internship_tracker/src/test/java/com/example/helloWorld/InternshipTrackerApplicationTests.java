package com.example.helloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
